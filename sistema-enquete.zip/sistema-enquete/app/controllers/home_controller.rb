class HomeController < ApplicationController
  def index
    @nome_app = "Sistema de Enquetes"
  end
end
