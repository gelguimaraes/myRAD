class RespostaController < ApplicationController
  before_action :set_respostum, only: [:show, :edit, :update, :destroy]

  # GET /resposta
  # GET /resposta.json
  def index
    @resposta = Respostum.all
  end

  # GET /resposta/1
  # GET /resposta/1.json
  def show
  @alternativa = Alternativa.find(Respostum.find(params[:id]).alternativa)
  end

  # GET /resposta/new
  def new
    @respostum = Respostum.new
    @respostum.build_entrevistado
    @enquetes = Enquete.all
    @alternativas = Alternativa.where(enquete_id: params[:id])
    @id_enquete = params[:id];
  end

  # GET /resposta/1/edit
  def edit
    @respostum.build_entrevistado if(!@respostum.entrevistado)
    @enquetes = Enquete.all
    @alternativas = Alternativa.where(enquete_id: params[:id_enquete])
    @id_enquete = params[:id_enquete];
  end

  # POST /resposta
  # POST /resposta.json
  def create
    @respostum = Respostum.new(respostum_params)
    @enquetes = Enquete.all
    @alternativas = Alternativa.where(enquete_id: params[:id])
    @id_enquete = params[:id];

    respond_to do |format|
      if @respostum.save
        format.html { redirect_to @respostum, notice: 'Respostum was successfully created.' }
        format.json { render :show, status: :created, location: @respostum }
      else
        format.html { render :new }
        format.json { render json: @respostum.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /resposta/1
  # PATCH/PUT /resposta/1.json
  def update
    respond_to do |format|
      if @respostum.update(respostum_params)
        format.html { redirect_to @respostum, notice: 'Respostum was successfully updated.' }
        format.json { render :show, status: :ok, location: @respostum }
      else
        format.html { render :edit }
        format.json { render json: @respostum.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /resposta/1
  # DELETE /resposta/1.json
  def destroy
    @respostum.destroy
    respond_to do |format|
      format.html { redirect_to resposta_url, notice: 'Respostum was successfully destroyed.' }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_respostum
      @respostum = Respostum.find(params[:id])
    end

    # Never trust parameters from the scary internet, only allow the white list through.
    def respostum_params
      params.require(:respostum).permit(:alternativa, :observacao, :enquete_id,
                                        entrevistado_attributes: [:id, :nome, :email, :respostum_id],
                                        enquete_attributes: [:id, :descricao],
                                        alternativas_attributes: [:id, :descricao, :enquete_id])
    end


  def method
    @method ||= check_method(get_header("rack.methodoverride.original_method") || get_header("REQUEST_METHOD"))
  end
end
