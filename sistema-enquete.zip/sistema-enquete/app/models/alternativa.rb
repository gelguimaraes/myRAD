class Alternativa < ApplicationRecord
  belongs_to :enquete
end
