class Enquete < ApplicationRecord
  has_many :alternativas
  has_many :respostums
  accepts_nested_attributes_for :alternativas, reject_if: :all_blank, allow_destroy: true
end
