class Entrevistado < ApplicationRecord
  belongs_to :respostum
end
