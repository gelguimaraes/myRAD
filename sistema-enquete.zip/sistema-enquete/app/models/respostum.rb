class Respostum < ApplicationRecord
  belongs_to :enquete
  has_one :entrevistado
  accepts_nested_attributes_for :entrevistado, reject_if: :all_blank, allow_destroy: true
  accepts_nested_attributes_for :enquete, reject_if: :all_blank, allow_destroy: true
end
