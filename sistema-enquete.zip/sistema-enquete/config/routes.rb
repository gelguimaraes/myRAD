Rails.application.routes.draw do
  get 'home/index'
  resources :resposta
  resources :enquetes
  get '/resposta/new/:id', to: 'resposta#new'
  get '/resposta/:id/edit/:id_enquete', to: 'resposta#edit'
  root 'home#index'
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
