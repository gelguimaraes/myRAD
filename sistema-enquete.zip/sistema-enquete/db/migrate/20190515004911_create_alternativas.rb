class CreateAlternativas < ActiveRecord::Migration[5.2]
  def change
    create_table :alternativas do |t|
      t.string :descricao
      t.references :enquete, foreign_key: true

      t.timestamps
    end
  end
end
