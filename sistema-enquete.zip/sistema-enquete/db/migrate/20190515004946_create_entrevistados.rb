class CreateEntrevistados < ActiveRecord::Migration[5.2]
  def change
    create_table :entrevistados do |t|
      t.string :nome
      t.string :email
      t.references :resposta, foreign_key: true

      t.timestamps
    end
  end
end
