require 'test_helper'

class AltenativaTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
