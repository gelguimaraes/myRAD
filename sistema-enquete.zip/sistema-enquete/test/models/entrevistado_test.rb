require 'test_helper'

class EntrevistadoTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
