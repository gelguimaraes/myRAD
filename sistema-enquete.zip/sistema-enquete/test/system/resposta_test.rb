require "application_system_test_case"

class RespostaTest < ApplicationSystemTestCase
  setup do
    @respostum = resposta(:one)
  end

  test "visiting the index" do
    visit resposta_url
    assert_selector "h1", text: "Resposta"
  end

  test "creating a Respostum" do
    visit resposta_url
    click_on "New Respostum"

    fill_in "Alternativa", with: @respostum.alternativa
    fill_in "Enquete", with: @respostum.enquete_id
    fill_in "Observacao", with: @respostum.observacao
    click_on "Create Respostum"

    assert_text "Respostum was successfully created"
    click_on "Back"
  end

  test "updating a Respostum" do
    visit resposta_url
    click_on "Edit", match: :first

    fill_in "Alternativa", with: @respostum.alternativa
    fill_in "Enquete", with: @respostum.enquete_id
    fill_in "Observacao", with: @respostum.observacao
    click_on "Update Respostum"

    assert_text "Respostum was successfully updated"
    click_on "Back"
  end

  test "destroying a Respostum" do
    visit resposta_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Respostum was successfully destroyed"
  end
end
